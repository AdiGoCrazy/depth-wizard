# SIH Presentation Draft: DepthWizard

---

## Slide 1: IDEA TITLE
**DepthWizard: Context-Aware Monocular Depth Estimation & 3D Terrain Flythrough**

**Proposed Solution to the Problem Statement:**
*   **Description:** DepthWizard is a rapid, single-view 3D elevation reconstruction engine. It takes a standard, flat 2D satellite or aerial RGB image (GeoTIFF, PNG, JPG) and instantly predicts the structural depth, outputting a true-metric scale Digital Surface Model (DSM) and a fully interactive 3D terrain flythrough.
*   **How it Addresses the Problem (Disaster Management):** Traditional DSM generation requires expensive LiDAR sensors, multi-pass stereo-imaging, or InSAR radar, all of which are slow and costly. In disaster scenarios (like sudden flooding or earthquakes), responders need immediate 3D topology. DepthWizard provides instant 3D intelligence using readily available 2D optical imagery.
*   **Innovation & Uniqueness:** Instead of training a narrow, rigid satellite-specific model, DepthWizard leverages the massive zero-shot capabilities of foundational AI models (*Depth Anything V2*). It uniquely bridges the "domain gap" (the model's confusion when looking top-down) via an innovative **Context-Aware Pipeline** that employs *FastSAM (Segment Anything)* to mathematically flatten and sharpen building rooftops, separating them cleanly from the ground.

---

## Slide 2: TECHNICAL APPROACH
**Technologies to be Used:**
*   **AI/ML Core:** PyTorch, *Depth Anything V2* (Vision Transformer), *FastSAM* (Segment Anything).
*   **Geospatial Processing:** `rasterio`, `gdal`, `numpy`, `scipy` (RANSAC Regression).
*   **Backend / API:** Python 3.13, FastAPI (acting as a dynamic traffic controller for AI inference).
*   **Frontend / 3D Engine:** HTML5, Vanilla JS, WebGL, *Three.js* (for real-time mesh displacement and flythrough rendering).

**Methodology and Process for Implementation:**
*   *(Note for PPT: Insert PIPELINE_FLOWCHART diagram here)*
*   **1. Ingestion:** Parses the GeoTIFF and extracts geospatial metadata (EPSG codes, bounding box).
*   **2. Context-Aware Forking:** A UI toggle dictates the execution path based on the environment.
*   **3. Urban Pathway:** 
    *   *Preprocessing:* Applies CLAHE (Contrast Limited Adaptive Histogram Equalization) and HSV shadow enhancement to force distinct edge boundaries.
    *   *Inference:* Depth Anything V2 generates relative depth.
    *   *Edge Flattening:* FastSAM detects building footprints and flattens the predicted depth inside those masks to remove "depth bleeding".
*   **4. Terrain Pathway (Bypass):** For natural landscapes, preprocessing and segmentation are explicitly bypassed to preserve the continuous, smooth topographic slopes of mountains and canyons.
*   **5. Scale Calibration & 3D Render:** Uses RANSAC regression against low-res SRTM 30m anchor data to convert relative depth to absolute metric height, exporting a GeoTIFF and streaming to a Three.js WebGL canvas.

---

## Slide 3: FEASIBILITY AND VIABILITY
**Analysis of Feasibility:**
*   The prototype successfully runs on consumer-grade hardware. By swapping heavy LiDAR processing for zero-shot Vision Transformers, the software can generate 3D models from standard 2D satellite feeds (Maxar, Planet, ISRO optical) in seconds, making rapid deployment highly feasible.

**Potential Challenges and Risks:**
*   **The Domain Gap:** AI models trained on forward-facing photography struggle with the nadir (top-down) perspective, often blurring building rooftops into the ground.
*   **The "Minecraft Canyon" Effect:** Aggressive edge-flattening algorithms designed for urban buildings destroy the smooth gradients of natural terrain, turning mountains into jagged, stepped plateaus.
*   **Specular Reflection:** Reflective surfaces like rivers or glass skyscrapers can trick depth estimators into predicting infinite depth (rendering as deep trenches).

**Strategies for Overcoming Challenges:**
*   **Context-Aware Routing:** We solved the "Minecraft Canyon" effect by introducing explicit logic that routes Urban and Terrain images through entirely different processing algorithms, ensuring natural slopes remain smooth.
*   **Algorithmic Band-Aids:** We employ FastSAM mask extraction to explicitly delineate buildings, overriding the AI's tendency to blur structures into the ground.

---

## Slide 4: IMPACT AND BENEFITS
**Potential Impact on the Target Audience:**
*   **Disaster Management (NDRF, ISRO):** Enables instant topological mapping of affected areas (e.g., assessing flood plains or landslide damage) using standard optical satellites when specialized radar/LiDAR is unavailable.
*   **Urban Planners:** Rapid 3D city modeling for infrastructure planning without commissioning expensive drone surveys.
*   **Defense & Reconnaissance:** Immediate 3D tactical visualization of unknown territories using single-pass optical satellite imagery.

**Benefits of the Solution:**
*   **Economic:** Massively reduces the cost of 3D data acquisition. Replaces million-dollar hardware sensors with software-driven AI inference.
*   **Temporal (Speed):** Cuts generation time from days (traditional photogrammetry) to literal seconds.
*   **Accessibility:** Democratizes 3D spatial data. Anyone with a 2D image and a web browser can render and explore a metric 3D environment.

---

## Slide 5: RESEARCH AND REFERENCES
**Details of Reference and Research Work:**
*   **Monocular Depth Estimation (MDE):** Extensive analysis of foundational models, specifically researching the zero-shot capabilities of *Depth Anything V2* (Yang et al., 2024) vs. domain-specific models like *Im2Height*.
*   **Zero-Shot Segmentation:** Research into utilizing *Fast Segment Anything (FastSAM)* (Zhao et al., 2023) as an architectural "Band-Aid" for structural edge retention in remote sensing data.
*   **Geospatial Calibration:** Implementation of robust RANSAC (Random Sample Consensus) statistical modeling to align relative depth predictions with coarse, low-resolution global SRTM (Shuttle Radar Topography Mission) DEM anchors.
*   *(Internal Project Logs: `IM2HEIGHT_ANALYSIS.md`, `DEPTH_ANYTHING_SATELLITE_ANALYSIS.md`, `MODEL_STRATEGY.md`)*
