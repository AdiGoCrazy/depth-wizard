# Terrain Failure Analysis: The "Minecraft Canyon" Effect

Based on the image you provided of the Hilly Terrain Showcase, the system has catastrophically failed to render natural topography. Instead of a smooth, continuous canyon or river valley, the terrain has been carved into massive, flat, blocky plateaus with sheer vertical cliffs. Entire sections of the river and mountain slopes look like giant stair-steps.

This failure is the direct mathematical result of the two major systems we just introduced in this git branch to fix the urban "Depth Bleeding."

---

## 1. Root Cause A: Instance Segmentation Depth Flattening (The Primary Culprit)

To fix the "melting blob" effect on buildings, we introduced **FastSAM** in `src/depth_wizard/segmentation.py`. 

### The Logic We Wrote:
1. FastSAM finds distinct regions in the image based on color/texture.
2. If the raw depth inside that region varies, we assume it's a building suffering from depth bleeding.
3. We forcefully overwrite every pixel inside that mask to a single, perfectly flat depth value (the 90th percentile).

### Why It Destroys Terrain:
Mountains, valleys, and riverbeds are *supposed* to have continuous depth gradients! 
FastSAM looks at the canyon and segments a rocky slope or a stretch of river based on its visual texture. Our algorithm blindly assumes this slope is a "building" and forcefully flattens the natural gradient into a flat plateau, snapping the edges to sheer 90-degree cliffs. We have effectively turned nature into a series of skyscrapers.

---

## 2. Root Cause B: Aggressive Shadow Preprocessing

To help the AI see sharp drops on buildings, we introduced the `ImagePreprocessor` which isolates the darkest 10% of pixels in the HSV color space and artificially darkens them by 50%.

### Why It Destroys Terrain:
In a deep rugged canyon, shadows naturally graduate along the slopes, providing subtle cues about the angle of the terrain. By crushing the blacks and deepening these shadows artificially, we destroy the subtle gradient information that *Depth Anything V2* relies on. Instead of inferring a sloping valley wall, the AI sees a pitch-black abyss, causing it to predict extreme, jagged depth chasms that don't actually exist.

---

## 3. The Core Architectural Conflict

We have encountered a fundamental dichotomy in 3D reconstruction:
*   **Urban Architecture** is fundamentally *discrete* (flat roofs, vertical walls, sharp 90-degree angles).
*   **Natural Terrain** is fundamentally *continuous* (slopes, gradients, smooth rolling topography).

An algorithm mathematically designed to enforce strict discrete boundaries (like our Mask Flattening) will inherently destroy continuous natural topography. Our pipeline currently treats every pixel as if it belongs to a city.

---

## 4. Proposed Solutions

Our pipeline must become "Context-Aware." It cannot apply "Building Flattening" logic blindly to mountains.

### Option A: The "Environment Context" Toggle (Recommended & Safest)
We add a parameter to the API request (e.g., `environment_type="urban" | "terrain"`). 
*   If `urban`, we run the full FastSAM + Preprocessing pipeline.
*   If `terrain`, we completely bypass the Preprocessor and FastSAM, feeding the raw image directly into *Depth Anything V2*. (Depth Anything V2 is actually incredible at continuous natural terrain straight out of the box when left alone).

### Option B: Algorithmic Mask Rejection (The "Smart" but Risky Fix)
We update `flatten_depth_by_masks()` in `segmentation.py` to analyze the geometry of the FastSAM masks. Buildings tend to be small, geometric polygons. Natural terrain masks tend to be massive, sprawling organic shapes. We could write rules to ignore masks that are extremely large or highly irregular, only flattening small geometric shapes. (Risk: FastSAM might still flatten small rocks into tiny buildings).

### Option C: Semantic Segmentation Swap (Heavy Compute)
We swap `FastSAM` (which segments *everything*) for a strict Semantic Segmentation model specifically trained *only* on buildings (like SpaceNet models). The flattening algorithm would literally only trigger on structures. (Risk: Requires sourcing and loading a 3rd AI model, risking OOM crashes again).

---

## User Review Required

> [!IMPORTANT]
> Since you need this to work flawlessly for a live demonstration showcasing both Urban and Rugged environments, **Option A** is the most foolproof solution. It allows us to keep our incredible urban fixes while letting the base AI handle the terrain naturally.
> 
> How would you like to proceed in fixing this?
