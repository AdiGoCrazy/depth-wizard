# Architecture Plan: Environment Context Toggle (Full-Stack)

Per the `/develop` skill workflow, this document outlines **Phase 1: Initial Planning & Architecture** for implementing the "Environment Context" toggle across the frontend and backend.

---

## 1. Requirement Analysis & Stack Adaptation
We need to give the user explicit control over how the backend mathematically processes the image, differentiating between discrete urban areas and continuous natural terrain.
*   **Backend (`api.py`):** The FastAPI `/api/process` endpoint must accept a new form-data parameter `environment` (enum: `"urban"` or `"terrain"`).
*   **Frontend (`index.html` / `app.js`):** The user interface must present a visually distinct toggle or selection mechanism for the user to specify the environment *before* submitting the file.

## 2. Resource & Hardware Profiling
*   **VRAM Impact:** Positive! When `"terrain"` is selected, the pipeline will completely bypass FastSAM, effectively saving 2GB of temporary VRAM allocation and reducing latency by several seconds.
*   **Compute Latency:** Terrain processing will be significantly faster than Urban processing.

## 3. Visual & Structural Mapping

### Execution Flowchart
```mermaid
flowchart TD
    A[Frontend: User selects 'Terrain' or 'Urban'] --> B[Frontend: Submit File + Environment Flag]
    B --> C[Backend: /api/process]
    C --> D[Phase 1: Ingestion]
    D --> E{Environment == 'urban'?}
    
    E -- YES --> F[Phase 1.5: Preprocessing (CLAHE + Shadows)]
    F --> G[Phase 2: Depth Inference]
    G --> H[Phase 2.5: FastSAM Segmentation Flattening]
    H --> I[Phase 3: Calibration & Export]
    
    E -- NO (terrain) --> J[Bypass Preprocessing]
    J --> K[Phase 2: Depth Inference]
    K --> L[Bypass Segmentation]
    L --> I
```

## 4. Threat & Failure Modeling (Unintended Consequences Report)

| Threat | Impact | Mitigation Strategy |
| :--- | :--- | :--- |
| **Invalid Enum Payload** | API Crash (HTTP 422) | Use FastAPI's data validation to strictly enforce the `environment` string to match exactly `"urban"` or `"terrain"`. Default to `"urban"` if missing. |
| **Frontend State Desync** | User thinks they processed Terrain, but UI sent Urban | The frontend `FormData` must explicitly pull the current state of the radio button/toggle at the exact millisecond the 'Upload' button is clicked. |
| **Unused VRAM Hoarding** | FastSAM stays in VRAM | Our VRAM swapping architecture already initializes FastSAM on CPU. If `terrain` is selected, FastSAM simply never loads to GPU, inherently preventing any hoarding. |

## 5. Proposed Changes (Code Modification Plan)

### [Backend Components]
#### [MODIFY] `src/depth_wizard/api.py`
- Update the `/api/process` endpoint to accept `environment: str = Form("urban")`.
- Wrap the Preprocessing and FastSAM phases in an `if environment == "urban":` block.

### [Frontend Components]
#### [MODIFY] `index.html`
- Inject a UI selection control (e.g., Radio Buttons or a sleek Toggle Switch) into the upload form area labeled "Environment Type".

#### [MODIFY] `src/app.js`
- Update the `FormData` construction inside the upload handler to append the selected environment value.

## User Gate (Review Required)

> [!IMPORTANT]
> **Awaiting User Approval**
> I have mapped out the architecture for the full-stack Environment Toggle. The flowchart demonstrates exactly how the backend will logically bypass the conflicting logic.
> 
> Please review the flowchart and the Threat Modeling report. If you approve this Phase 1 Architecture, I will proceed to Phase 2 (Modular Documentation & Test Planning) and stop there!
