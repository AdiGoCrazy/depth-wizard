# Actions Report: Indian Village Testing Branch

Per your request, I have completely frozen code modifications and focused entirely on administrative staging and data sourcing for our new test parameters.

## 1. Branch Management
*   **Created and checked out a new git branch:** `village`.
*   All work moving forward regarding the rural structural testing will be safely contained within this branch.

## 2. Updated Hero Image Requirements
I analyzed the `HERO_IMAGE_REQUIREMENTS.md` file and appended a highly detailed **Scene C: The Indian Village Showcase (Rural/Semi-Urban)**. 

To ensure the FastSAM and Depth Anything V2 models don't fail, I specifically added constraints tailored to Indian villages:
*   **Contrast is Key:** We must ensure the roofs of the houses visually pop against the dirt/unpaved roads (e.g., using terracotta tiles or bright painted roofs against brown earth). If they blend together, FastSAM will merge the house and the road into one flat blob.
*   **Canopy Avoidance:** I explicitly warned against densely forested villages. If tree canopies cover the houses, the AI will perceive the top of the forest as a single, undulating, bumpy building.

## 3. Image Sourcing Plan
To rigorously test the system, I have sourced (identified the exact ideal targets for) 3 new test images that strictly follow our `HERO_IMAGE_REQUIREMENTS.md`:

### Sourced Image 1: Urban Structural (Scene A)
*   **Target:** **Downtown Chicago, USA (The Loop)**
*   **Why it works:** Chicago features massive, distinctly geometric skyscrapers with flat roofs that heavily contrast with the dark asphalt grids and the Chicago River. The 90-degree angles are perfect for testing our FastSAM segmentation flattening algorithm.

### Sourced Image 2: Rugged Terrain (Scene B)
*   **Target:** **Spiti Valley, Himachal Pradesh, India**
*   **Why it works:** It offers extreme, jagged topological drops and winding river gorges, entirely free of snow cover in the summer months. It is an ultimate stress-test for the "Terrain Context" API bypass we just built, ensuring the model predicts smooth, sweeping continuous gradients.

### Sourced Image 3: Indian Village (Scene C)
*   **Target:** **Desert Village near Jaisalmer, Rajasthan, India**
*   **Why it works:** Villages in this region are densely packed with highly structural, geometric houses (often painted distinctly or built with yellow sandstone) surrounded by flat, arid earth with minimal tree canopy. This provides the absolute perfect high-contrast environment to test if our urban algorithm can handle organic, non-grid rural layouts without melting the houses into the ground.

---
**Status:** Ready to proceed. No backend or frontend code has been touched on this branch yet.
