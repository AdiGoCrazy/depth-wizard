# Phase 3 Execution: Environment Context Toggle (Full-Stack)

- [x] Initialize Phase 3
- [x] Modify `src/depth_wizard/api.py` to accept `environment` parameter and fork the AI pipeline.
- [x] Update `index.html` to inject a clean UI toggle for "Urban" vs "Terrain" selection.
- [x] Update `src/app.js` to pass the selected `environment` state in the `FormData` payload.
- [x] Execute `tests/test_api.py` to ensure routing and payload validation works.
- [x] Restart backend server and verify functionality.
- [x] Conclude with updated `walkthrough.md`.
