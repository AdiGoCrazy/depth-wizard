# DepthWizard: Full Project Lifecycle Report

This document serves as a comprehensive history of the **DepthWizard** project, tracing its evolution from the initial problem statement to its current state as a context-aware 3D satellite visualization engine.

## 1. The Problem Statement & Inception
The project was initiated to tackle **ISRO Hackathon Problem Statement 26175** under the theme of *Disaster Management*. 
The core objective was to generate accurate Digital Elevation Models (DEMs) and Digital Surface Models (DSMs) from **single-view optical satellite/aerial RGB imagery**. Traditional methods like LiDAR or stereo-pairs are expensive and require multiple passes. The goal was to build a system that could take a flat, 2D satellite image and instantly predict its 3D depth, export it as a metric GeoTIFF, and render it in an interactive 3D flythrough—a critical capability for rapid flood modeling and urban reconnaissance.

The foundational requirements and architecture were mapped out in the **[REQUIREMENTS.md](file:///home/adi/Documents/Programming/Depth-Wizard/REQUIREMENTS.md)** file.

## 2. Research & Planning State
Before writing any code, we conducted extensive research on the state-of-the-art Monocular Depth Estimation (MDE) landscape. This research was documented in three core analysis files:

*   **[IM2HEIGHT_ANALYSIS.md](file:///home/adi/Documents/Programming/Depth-Wizard/IM2HEIGHT_ANALYSIS.md):** Explored existing satellite-specific models. We discovered that many models trained specifically on satellite data suffered from poor generalization outside their training domains.
*   **[DEPTH_ANYTHING_SATELLITE_ANALYSIS.md](file:///home/adi/Documents/Programming/Depth-Wizard/DEPTH_ANYTHING_SATELLITE_ANALYSIS.md):** Analyzed the viability of using a foundational zero-shot model (Depth Anything V2). We noted its incredible zero-shot generalization but identified a critical "domain gap": because it was trained on standard forward-facing photography, it struggled with the top-down (nadir) perspective of satellites, often blending building rooftops into the ground.
*   **[MODEL_STRATEGY.md](file:///home/adi/Documents/Programming/Depth-Wizard/MODEL_STRATEGY.md):** Based on the analysis, we finalized our strategy. We chose **Depth Anything V2** as the core engine due to its raw power, but decided to employ a "Band-Aid" architecture to fix its satellite shortcomings. We introduced **FastSAM (Segment Anything)** as a secondary model to detect building footprints and mathematically flatten/sharpen their depth edges, forcing crisp 3D structures.

This architecture was visualized and cemented in the **[PIPELINE_FLOWCHART.md](file:///home/adi/Documents/Programming/Depth-Wizard/PIPELINE_FLOWCHART.md)**.

## 3. Initial Implementation
With the strategy defined, we built the core pipeline:
1.  **Ingestion:** Handling GeoTIFFs and standard images.
2.  **Inference:** Running Depth Anything V2 to get relative depth.
3.  **Segmentation:** Running FastSAM to detect masks and flatten the depth inside those masks (solving the bleeding edges problem for urban buildings).
4.  **Calibration:** Using RANSAC regression against low-res SRTM DEM anchors to convert relative depth into true metric scale.
5.  **Frontend:** A Three.js based web UI for immersive 3D flythroughs.

## 4. Revisions & The "Minecraft Canyon" Crisis
While the system performed exceptionally well on urban imagery, testing it on natural terrain revealed a critical flaw. 
As documented in **[TERRAIN_FAILURE_ANALYSIS.md](file:///home/adi/.gemini/antigravity/brain/b0f62b67-f4a6-4351-b304-33b806900d5a/TERRAIN_FAILURE_ANALYSIS.md)**, the system failed catastrophically on mountain ranges and canyons. The FastSAM edge-flattening logic—designed to make building roofs flat—was being applied to natural hills. This resulted in smooth gradients being chopped into jagged, stepped plateaus, a phenomenon we dubbed the "Minecraft Canyon" effect.

## 5. The Context-Aware Pipeline (Tweaks)
To resolve this, we drafted a new **[implementation_plan.md](file:///home/adi/.gemini/antigravity/brain/b0f62b67-f4a6-4351-b304-33b806900d5a/implementation_plan.md)** heavily focused on intelligent routing.

Using a rigorous `/develop` workflow spanning three phases, we executed the following:
*   **Frontend UI:** Added a toggle to the web interface allowing the user to explicitly define the context: **Urban** vs **Terrain**.
*   **Backend Routing (`api.py`):** Rewrote the FastAPI endpoints to act as a traffic controller.
    *   If **Urban** is selected, the image undergoes Preprocessing (CLAHE + Shadow enhancement) and FastSAM segmentation to ensure crisp buildings.
    *   If **Terrain** is selected, the pipeline gracefully bypasses Preprocessing and FastSAM entirely, feeding the raw image only to Depth Anything V2 to preserve the natural, smooth topographic slopes.
*   **Testing:** We heavily updated the `tests/test_api.py` suite, mocking the file ingestion to ensure the API safely forks and validates the payloads without crashing. 

This successfully fixed the terrain rendering, as summarized in the **[walkthrough.md](file:///home/adi/.gemini/antigravity/brain/b0f62b67-f4a6-4351-b304-33b806900d5a/walkthrough.md)**. These changes were safely committed and merged into the `master` branch.

## 6. Curating Demo Assets & The Indian Village Initiative
To prepare for the final prototype presentation, we established strict criteria for the satellite imagery in **[HERO_IMAGE_REQUIREMENTS.md](file:///home/adi/Documents/Programming/Depth-Wizard/HERO_IMAGE_REQUIREMENTS.md)** (requiring zero clouds, true nadir perspective, and high contrast).

Most recently, we expanded our testing scope to include rural environments. We created a new git branch (`village`) and appended **Scene C: The Indian Village Showcase** to the requirements, specifically seeking high-contrast roofs and avoiding dense tree canopies that confuse the segmentation engine. 

As detailed in the final **[report.md](file:///home/adi/.gemini/antigravity/brain/b0f62b67-f4a6-4351-b304-33b806900d5a/report.md)**, we updated our Python fetch script to source three perfect test images directly from Esri satellite feeds:
1.  **Urban:** Downtown Chicago (The Loop)
2.  **Terrain:** Spiti Valley, Himachal Pradesh
3.  **Village:** Kuldhara Village, Jaisalmer, Rajasthan

These assets are now downloaded into the `demo_assets` directory, and the fully context-aware backend is running, ready for the ultimate stress test.
